import { useEffect, useMemo, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  ArrowRight, Clock, MapPin, Share2, Users, HeartHandshake, MessageSquare,
  BookOpen, Music, Flame, HandCoins, ShieldCheck, ReceiptText, Smartphone,
  Tent, Wallet, ClipboardCheck, Bell, Camera, Video, Newspaper, CalendarDays,
} from 'lucide-react'
import { apiGet, getUser } from '../api.js'
import { useAuthModal } from '../context/AuthModal.jsx'
import { shareEventOnFacebook } from '../utils/share.js'
import AddToCalendarButton from '../components/AddToCalendarButton.jsx'
import { resolveImageUrl } from '../lib/media.js'
import { useHomeMotion } from '../components/home/motion.js'
import HomeFooter from '../components/home/HomeFooter.jsx'
import { FacebookIcon, InstagramIcon, TikTokIcon, SOCIALS } from '../components/home/SocialIcons.jsx'
import '../styles/home.css'
import '../styles/home-extra.css'
import '../styles/home3.css'

const MONTHS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC']
const DAYS = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT']

function parseDate(d) {
  const [y, m, day] = String(d || '').slice(0, 10).split('-').map(Number)
  return y ? new Date(y, m - 1, day) : null
}

function countdown(d) {
  const x = parseDate(d)
  if (!x) return ''
  const t = new Date(); t.setHours(0, 0, 0, 0)
  const n = Math.round((x - t) / 864e5)
  return n <= 0 ? 'Today' : n === 1 ? 'Tomorrow' : `In ${n} days`
}

function dateParts(d) {
  const x = parseDate(d)
  return x ? { day: x.getDate(), mon: MONTHS[x.getMonth()], dow: DAYS[x.getDay()] } : null
}

const VISION = 'An empowered generation that is able to inspire the community through their kindled passion in Christ.'
// Palitan ang caption dito kung gusto mo
const GALLERY = [
  { img: 'gallery-1', w: 1000, h: 702, cap: 'Life Generation Fellowship' },
  { img: 'gallery-2', w: 1000, h: 750, cap: 'Growing in faith, living in fellowship.' },
  { img: 'gallery-3', w: 760, h: 937, cap: 'United in His calling.' },
  { img: 'gallery-4', w: 1000, h: 750, cap: 'Group photo' },
  { img: 'gallery-5', w: 1000, h: 750, cap: 'United by purpose.' },
]

const KEY_FROM = 'kindled'

const CHANNELS = [
  { icon: FacebookIcon, name: 'Facebook', sub: 'Our official page', desc: 'Event posts, photo albums and weekly reminders.', tags: ['Events', 'Albums'], cta: 'Follow us', href: SOCIALS.facebook, tone: 'fb' },
  { icon: FacebookIcon, name: 'Radical LED Calapan', sub: 'Youth leadership and campus movement', desc: 'Leadership trainings and campus outreach updates.', tags: ['Leadership', 'Campus'], cta: 'Visit page', href: SOCIALS.radical, tone: 'fb' },
  { icon: InstagramIcon, name: 'Instagram', sub: '@lifegencalapan', desc: 'Photo highlights and stories from our nights together.', tags: ['Photos', 'Stories'], cta: 'Follow us', href: SOCIALS.instagram, tone: 'ig' },
  { icon: TikTokIcon, name: 'TikTok', sub: '@life.generation7', desc: 'Short clips from worship, games and fellowship.', tags: ['Clips', 'Moments'], cta: 'Watch', href: SOCIALS.tiktok, tone: 'tt' },
]
const USES = [
  { icon: Flame, t: 'Youth nights', d: 'Worship, sound and venue.' },
  { icon: Tent, t: 'Camps', d: 'Retreats and leadership camps.' },
  { icon: HeartHandshake, t: 'Outreach', d: 'Serving the community.' },
  { icon: BookOpen, t: 'Discipleship', d: 'D-Group materials and training.' },
]

const STRIP = [
  { icon: Music, label: 'Worship' },
  { icon: BookOpen, label: 'Discipleship' },
  { icon: MessageSquare, label: 'Prayer' },
  { icon: HeartHandshake, label: 'Service' },
  { icon: Users, label: 'Community' },
]

function Tile({ tile }) {
  const Icon = tile.icon
  const inner = (
    <>
      <span className="lg-tile-img" data-parallax="0.07" aria-hidden="true">
        <img src={`/images/${tile.img}.webp`} alt="" width="640" height="800" loading="lazy" decoding="async" />
      </span>
      <span className="lg-tile-go" aria-hidden="true">
        <ArrowRight size={18} />
      </span>
      <span className="lg-tile-body">
        <span className="lg-tile-chip" aria-hidden="true">
          <Icon size={20} strokeWidth={1.8} />
        </span>
        <span className="lg-tile-title">{tile.title}</span>
        <span className="lg-tile-sub">{tile.sub}</span>
      </span>
    </>
  )
  return tile.action ? (
    <button type="button" className="lg-tile" onClick={tile.action}>
      {inner}
    </button>
  ) : (
    <Link to={tile.to} className="lg-tile">
      {inner}
    </Link>
  )
}

export default function Home() {
  const user = getUser()
  const { openRegister } = useAuthModal()
  const rootRef = useRef(null)
  const [events, setEvents] = useState([])
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    apiGet('/api/events')
      .then((d) => Array.isArray(d) && setEvents(d))
      .catch(() => {})
      .finally(() => setLoaded(true))
  }, [])

  const upcoming = useMemo(() => {
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    return events
      .filter((e) => {
        const d = parseDate(e.event_date)
        return d && d >= today
      })
      .sort((a, b) => String(a.event_date).localeCompare(String(b.event_date)))
      .slice(0, 4)
  }, [events])

  const next = upcoming[0]
  const nextParts = next && dateParts(next.event_date)

  useHomeMotion(rootRef, `${loaded}-${upcoming.length}`)

  const tiles = [
    user
      ? { title: 'Join an event', sub: 'See what is coming up and sign up.', icon: Flame, to: '/events', img: 'tile-new' }
      : { title: "I'm new", sub: 'Make your free member account in a minute.', icon: Flame, action: openRegister, img: 'tile-new' },
    { title: 'Find a D-Group', sub: 'Small groups where you grow with friends.', icon: Users, to: '/dgroups', img: 'tile-dgroup' },
    { title: 'I need prayer', sub: 'Share a request on the prayer wall.', icon: MessageSquare, to: '/prayer', img: 'tile-prayer' },
    { title: 'I want to serve', sub: 'Join a ministry team that fits you.', icon: HeartHandshake, to: '/ministries', img: 'tile-serve' },
  ]

  const words = VISION.split(' ')
  const keyIndex = words.findIndex((w) => w.startsWith(KEY_FROM))

  return (
    <>
    <main className="lg-home" ref={rootRef}>
      {/* ===== HERO ===== */}
      <section className="lg-hero" data-hero aria-label="Welcome">
        <div className="lg-hero-media" data-parallax="0.22" aria-hidden="true">
          <img src="/hero-bg.jpg" alt="" width="1376" height="768" fetchPriority="high" decoding="async" />
        </div>

        <div className="lg-wrap">
          <div className="lg-hero-inner" data-hero-fade>
            <div className="lg-hero-text">
              <span className="lg-eyebrow" data-reveal>Youth organization · Calapan</span>
              <h1 className="lg-title">
                <span className="lg-line"><span style={{ '--d': '0.1s' }}>A place for</span></span>
                <span className="lg-line"><span className="lg-accent" style={{ '--d': '0.25s' }}>Imperfect people</span></span>
              </h1>
              <p className="lg-hero-sub" data-reveal style={{ '--d': '0.45s' }}>
                {VISION}
              </p>
              <div className="lg-cta" data-reveal style={{ '--d': '0.6s' }}>
                {user ? (
                  <Link to={user.role === 'admin' ? '/admin' : (user.role === 'officer' ? '/officer' : '/dashboard')} className="lg-btn lg-btn-primary">
                    {user.role === 'admin' ? 'Open admin' : (user.role === 'officer' ? 'Officer portal' : 'My profile')} <ArrowRight size={18} />
                  </Link>
                ) : (
                  <>
                    <button type="button" className="lg-btn lg-btn-primary" onClick={openRegister}>
                      Join the movement <ArrowRight size={18} />
                    </button>
                    <Link to="/login" className="lg-btn lg-btn-line">
                      Sign in
                    </Link>
                  </>
                )}
              </div>
            </div>

            {next && nextParts && (
              <Link to={`/events/${next.id}`} className="lg-next" data-reveal style={{ '--d': '0.75s' }}>
                <span className="lg-next-date">
                  <span>
                    <b>{nextParts.day}</b>
                    <small>{nextParts.mon}</small>
                  </span>
                </span>
                <span className="lg-next-body">
                  <em>Next gathering</em>
                  <strong>{next.title}</strong>
                  <span>
                    {[nextParts.dow, next.event_time, next.location].filter(Boolean).join(' · ')}
                  </span>
                </span>
                <ArrowRight size={18} />
              </Link>
            )}
          </div>
        </div>
      </section>

      {/* ===== STRIP (hindi gumagalaw) ===== */}
      <ul className="lg-strip">
        {STRIP.map(({ icon: Icon, label }) => (
          <li key={label}>
            <Icon size={22} strokeWidth={1.8} /> {label}
          </li>
        ))}
      </ul>

      {/* ===== GATHERINGS ===== */}
      <section className="lg-section" id="gatherings">
        <div className="lg-wrap lg-split">
          <div className="lg-split-aside" data-reveal>
            <span className="lg-eyebrow">Gatherings</span>
            <h2 className="lg-h2">Come as you are</h2>
            <p className="lg-lead">Meetings, youth nights and special events. Sign up so we can save you a spot.</p>
          </div>

          <div>
            <div className="lg-ag">
              {upcoming.length === 0 ? (
                <p className="lg-empty" data-reveal>
                  {loaded
                    ? 'No gatherings are posted right now. Follow our Facebook page to hear about the next one.'
                    : 'Loading gatherings…'}
                  {loaded && (
                    <>
                      {' '}
                      <a href={SOCIALS.facebook} target="_blank" rel="noopener noreferrer">Open Facebook</a>
                    </>
                  )}
                </p>
              ) : (
                <>
                  <article className="lg-fe" data-reveal>
                    <span className="lg-fe-bg" data-parallax="0.1" aria-hidden="true">{nextParts?.day}</span>
                    <div className="lg-fe-top">
                      <span className="lg-fe-tag"><Flame size={14} aria-hidden="true" /> Next gathering</span>
                      <span className="lg-fe-count">{countdown(next.event_date)}</span>
                    </div>
                    <Link to={`/events/${next.id}`} className="lg-fe-title">{next.title}</Link>
                    <ul className="lg-fe-meta">
                      <li><CalendarDays size={16} aria-hidden="true" /> {nextParts?.dow}, {nextParts?.mon} {nextParts?.day}</li>
                      {next.event_time && <li><Clock size={16} aria-hidden="true" /> {next.event_time}</li>}
                      {next.location && <li><MapPin size={16} aria-hidden="true" /> {next.location}</li>}
                    </ul>
                    <div className="lg-fe-acts">
                      <Link to={`/events/${next.id}`} className="lg-fe-go">View details <ArrowRight size={18} aria-hidden="true" /></Link>
                      <AddToCalendarButton event={next} variant="icon" className="lg-ev-btn" />
                      <button type="button" className="lg-ev-btn" onClick={() => shareEventOnFacebook(next.id, next.title)} aria-label={`Share ${next.title} on Facebook`} title="Share on Facebook"><Share2 size={18} /></button>
                    </div>
                  </article>

                  {upcoming.length > 1 && (
                    <ol className="lg-tl">
                      {upcoming.slice(1).map((ev, i) => {
                        const p = dateParts(ev.event_date)
                        return (
                          <li className="lg-tli" key={ev.id} data-reveal style={{ '--d': `${i * 0.1}s` }}>
                            <span className="lg-tli-dot" aria-hidden="true" />
                            <time className="lg-tli-date" dateTime={String(ev.event_date).slice(0, 10)}><b>{p?.day}</b> {p?.mon} <i>{p?.dow}</i></time>
                            <div className="lg-tli-card">
                              <Link to={`/events/${ev.id}`} className="lg-tli-main">
                                <strong>{ev.title}</strong>
                                <span className="lg-tli-meta">
                                  {ev.event_time && <span><Clock size={14} aria-hidden="true" /> {ev.event_time}</span>}
                                  {ev.location && <span><MapPin size={14} aria-hidden="true" /> {ev.location}</span>}
                                  <span className="lg-tli-in">{countdown(ev.event_date)}</span>
                                </span>
                              </Link>
                              <div className="lg-tli-acts">
                                <AddToCalendarButton event={ev} variant="icon" className="lg-ev-btn" />
                                <button type="button" className="lg-ev-btn" onClick={() => shareEventOnFacebook(ev.id, ev.title)} aria-label={`Share ${ev.title} on Facebook`} title="Share on Facebook"><Share2 size={18} /></button>
                                <Link to={`/events/${ev.id}`} className="lg-ev-btn lg-tli-go" aria-label={`Open ${ev.title}`}><ArrowRight size={18} /></Link>
                              </div>
                            </div>
                          </li>
                        )
                      })}
                    </ol>
                  )}
                </>
              )}
            </div>
            <div className="lg-more" data-reveal>
              <Link to="/events" className="lg-btn lg-btn-outline">
                See all events <ArrowRight size={18} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ===== START HERE (tiles) ===== */}
      <section className="lg-section" id="start" style={{ paddingTop: 0 }}>
        <div className="lg-wrap">
          <div className="lg-tiles-head" data-reveal>
            <div>
              <span className="lg-eyebrow">Find your place</span>
              <h2 className="lg-h2">Where do you<br />want to start?</h2>
            </div>
            <p className="lg-lead" style={{ margin: 0 }}>Four easy ways in. Pick the one that fits you today.</p>
          </div>
          <div className="lg-tiles" data-reveal style={{ '--d': '0.1s' }}>
            {tiles.map((t) => (
              <Tile tile={t} key={t.title} />
            ))}
          </div>
        </div>
      </section>

      {/* ===== GALLERY ===== */}
      <section className="lg-section lg-wall" id="moments">
        <div className="lg-wrap">
          <div className="lg-tiles-head" data-reveal>
            <div>
              <span className="lg-eyebrow">Our people</span>
              <h2 className="lg-h2">Moments together</h2>
            </div>
            <p className="lg-lead" style={{ margin: 0 }}>A few snapshots from our gatherings.</p>
          </div>
          <div className="lg-gallery">
            {GALLERY.map((g, i) => (
              <figure className={`lg-pic lg-pic-${i + 1}`} key={g.img} data-reveal style={{ '--d': `${i * 0.08}s` }}>
                <div className="lg-pic-in" data-parallax={i % 2 ? '-0.03' : '0.04'}>
                  <div className="lg-pic-frame">
                    <span className="lg-pic-photo">
                      <img src={`/images/${g.img}.webp`} alt={g.cap} width={g.w} height={g.h} loading="lazy" decoding="async" />
                    </span>
                  </div>
                  <figcaption>{g.cap}</figcaption>
                </div>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* ===== STATEMENT ===== */}
      <section className="lg-section lg-statement-sec">
        <div className="lg-wrap">
          <span className="lg-eyebrow" data-reveal>Our vision</span>
          <p className="lg-statement" data-statement aria-label={VISION}>
            {words.map((w, i) => (
              <span key={i} aria-hidden="true">
                <span className={`lg-w${keyIndex >= 0 && i >= keyIndex ? ' is-key' : ''}`}>{w}</span>{' '}
              </span>
            ))}
          </p>
          <span className="lg-note" data-reveal>young, rooted, and sent out.</span>
        </div>
      </section>

      {/* ===== FOLLOW ALONG ===== */}
      <section className="lg-section" id="updates">
        <div className="lg-wrap">
          <div className="lg-tiles-head" data-reveal>
            <div>
              <span className="lg-eyebrow">What is happening</span>
              <h2 className="lg-h2">Follow along</h2>
            </div>
            <p className="lg-lead" style={{ margin: 0 }}>Photos, recaps and announcements from Life Generation.</p>
          </div>
          <div className="lg-fa" data-reveal style={{ '--d': '0.1s' }}>
            {CHANNELS.map(({ icon: Icon, name, sub, desc, tags, cta, href, tone }, i) => (
              <a className={`lg-fa-item is-${tone}`} key={name} href={href} target="_blank" rel="noopener noreferrer" style={{ '--i': i }}>
                <span className="lg-fa-orbw" data-parallax={i % 2 ? '0.05' : '-0.04'} aria-hidden="true"><span className="lg-fa-orb"><Icon size={34} /></span></span>
                <strong>{name}</strong>
                <span className="lg-fa-sub">{sub}</span>
                <span className="lg-fa-desc">{desc}</span>
                <span className="lg-fa-tags">{tags.map((t) => <i key={t}>{t}</i>)}</span>
                <span className="lg-fa-cta">{cta} <ArrowRight size={16} aria-hidden="true" /></span>
              </a>
            ))}
          </div>
          <ul className="lg-tips" data-reveal style={{ '--d': '0.15s' }}>
            <li><Bell size={20} aria-hidden="true" /><span><b>Turn on notifications</b>We post schedules and changes there first.</span></li>
            <li><Share2 size={20} aria-hidden="true" /><span><b>Share a post</b>Invite a friend to the next gathering.</span></li>
            <li><MessageSquare size={20} aria-hidden="true" /><span><b>Send us a message</b>Questions are always welcome.</span></li>
          </ul>
        </div>
      </section>

      {/* ===== GIVE ===== */}
      <section className="lg-section lg-give" id="give" aria-labelledby="give-h">
        <span className="lg-give-ring" data-parallax="-0.08" aria-hidden="true" />
        <div className="lg-wrap lg-give-grid">
          <div data-reveal>
            <span className="lg-eyebrow">Giving</span>
            <h2 className="lg-h2" id="give-h">Give from<br />the heart</h2>
            <p className="lg-lead">There is no required amount here. Whatever you place in the offering, big or small, helps fund youth nights, camps, outreach and discipleship in Calapan, and it is received with gratitude.</p>
            <ul className="lg-uses">
              {USES.map(({ icon: Icon, t, d }) => (
                <li key={t}><span><Icon size={20} aria-hidden="true" /></span><div><b>{t}</b><small>{d}</small></div></li>
              ))}
            </ul>
          </div>

          <div className="lg-give-card" data-reveal style={{ '--d': '0.1s' }}>
            <blockquote className="lg-give-verse">
              <HeartHandshake size={22} aria-hidden="true" />
              <p>“Each of you should give what you have decided in your heart to give, not reluctantly or under compulsion, for God loves a cheerful giver.”</p>
              <cite>2 Corinthians 9:7</cite>
            </blockquote>
            <ol className="lg-give-steps">
              <li><b>Choose a way</b><span>GCash, Maya or bank transfer.</span></li>
              <li><b>Send and submit</b><span>Fill the short form with your reference number.</span></li>
              <li><b>We confirm</b><span>An officer verifies it and your code shows the status.</span></li>
            </ol>
            <div className="lg-give-row">
              <Link to="/give" className="lg-btn lg-btn-primary lg-give-go">
                <HandCoins size={18} aria-hidden="true" /> Give as you are led
              </Link>
              <span className="lg-give-note"><ShieldCheck size={16} aria-hidden="true" /> Checked by our officers</span>
            </div>
            <p className="lg-give-policy">
              By giving you agree to our <Link to="/giving-policy">Giving policy</Link>. See also our <Link to="/privacy">Privacy policy</Link>.
            </p>
          </div>
        </div>
      </section>

      {/* ===== CTA (guests lang) ===== */}
      {!user && (
        <section className="lg-section lg-cta-band">
          <div className="lg-wrap">
            <h2 className="lg-h2" data-reveal>Ready for your next step?</h2>
            <p data-reveal style={{ '--d': '0.1s' }}>
              Become a member of Life Generation. It is free, and you can sign up in a minute.
            </p>
            <div className="lg-cta" data-reveal style={{ '--d': '0.2s' }}>
              <button type="button" className="lg-btn lg-btn-dark" onClick={openRegister}>
                Join Life Generation <ArrowRight size={18} />
              </button>
              <Link to="/login" className="lg-btn lg-btn-outline">
                I already have an account
              </Link>
            </div>
          </div>
        </section>
      )}

    </main>
    <HomeFooter />
    </>
  )
}
